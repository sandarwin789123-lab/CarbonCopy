package main

import (
	"fmt"
	"os"
)

func isValid(board *[9][9]int, r, c, n int) bool {
	for i := 0; i < 9; i++ {
		if board[r][i] == n || board[i][c] == n {
			return false
		}
	}
	br := (r / 3) * 3
	bc := (c / 3) * 3
	for i := 0; i < 3; i++ {
		for j := 0; j < 3; j++ {
			if board[br+i][bc+j] == n {
				return false
			}
		}
	}
	return true
}

func solve(board *[9][9]int) bool {
	for r := 0; r < 9; r++ {
		for c := 0; c < 9; c++ {
			if board[r][c] == 0 {
				for n := 1; n <= 9; n++ {
					if isValid(board, r, c, n) {
						board[r][c] = n
						if r == 0 {
							fmt.Println(board[r][c], "board[r][c]")
							fmt.Println(board, "_board")
						}
						if solve(board) {
							return true
						}
						board[r][c] = 0

					}
				}
				return false
			}
		}
	}
	return true
}

func main() {
	if len(os.Args) != 10 {
		return
	}

	var board [9][9]int

	// Parse input
	for i := 1; i <= 9; i++ {
		row := os.Args[i]
		for j := 0; j < 9; j++ {
			ch := row[j : j+1] // extract string of length 1
			if ch != "." {
				board[i-1][j] = int(ch[0] - '0') // convert char to int WITHOUT strconv/byte/rune
			}
		}
		//fmt.Println(board)
	}

	// Solve
	solve(&board)

	/*


		// Print result
		for i := 0; i < 9; i++ {
			for j := 0; j < 9; j++ {
				fmt.Print(board[i][j])
				if j != 8 {
					fmt.Print(" ")
				}
			}
			fmt.Println()
		}
	*/
}

/*
func FindMissingNumsInRow(matrix [][]int, row int) []int {
	allNumbers := []int{1, 2, 3, 4, 5, 6, 7, 8, 9}
	var numsInMatrix []int
	for i := row; i <= row; i++ {
		for j := 0; j < len(matrix[i]); j++ {
			numToFind := matrix[i][j]
			if numToFind > 0 {
				if !NotIn(allNumbers, numToFind) {
					numsInMatrix = append(numsInMatrix, numToFind)
				}
			}
		}
	}
	res := Except(allNumbers, numsInMatrix)
	return res
}

func FindMissingNumsInCol(matrix [][]int, row, col int) []int {
	allNumbers := []int{1, 2, 3, 4, 5, 6, 7, 8, 9}
	var numsInMatrix []int
	for i := row; i < len(matrix); i++ {
		//for j := col; j < len(matrix[i]); j++ {
		numToFind := matrix[i][col]
		if numToFind > 0 {
			if !NotIn(allNumbers, numToFind) {
				numsInMatrix = append(numsInMatrix, numToFind)
			}
		}
		//}
	}
	res := Except(allNumbers, numsInMatrix)
	return res
}

func FindMissingNumsInBox(matrix [][]int, row, col int) []int {
	allNumbers := []int{1, 2, 3, 4, 5, 6, 7, 8, 9}
	var result []int
	for i := row; i <= row; i++ {
		for j := col; j < len(matrix[i]); j++ {
			numToFind := matrix[i][j]
			if NotIn(allNumbers, numToFind) {
				result = append(result, numToFind)
			}
		}
	}
	return result
}

/*
missingNumsInRow := FindMissingNumsInRow(matrix, i)
//fmt.Println(missingNumsInRow)
missingNumsInCol := FindMissingNumsInCol(matrix, i, j)
fmt.Println(missingNumsInCol)
break

func NotIn(arr []int, value int) bool {
	if len(arr) == 0 {
		return true
	}
	if arr[0] == value {
		return false // found
	}
	return NotIn(arr[1:], value)
}
func Except(a, b []int) []int {
	result := []int{}

	for _, v := range a {
		found := false
		for _, x := range b {
			if v == x {
				found = true
				break
			}
		}
		if !found {
			result = append(result, v)
		}
	}

	return result
}
*/
