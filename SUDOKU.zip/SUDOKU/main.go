package main

import (
	"fmt"
	"os"
)

func main() {
	args := os.Args[1:]

	if len(args) == 9 {
		maxOfRooms := 9
		matrix := make([][]int, maxOfRooms)

		//create 9*9 matrix
		for i := 0; i < maxOfRooms; i++ {
			matrix[i] = make([]int, maxOfRooms)
		}

		//fill the matrix using the command-line inputs, converting each ‘.’ to 0
		for i := 0; i < len(args); i++ {
			for j := 0; j < len(args[i]); j++ {
				matrix[i][j] = StringToInt(string(args[i][j]))
			}
		}

		//check duplicate number in the same row
		for r := 0; r < len(matrix); r++ {
			for c := 0; c < len(matrix[r]); c++ {
				for f := c + 1; f < len(matrix[r])-c; f++ {
					if matrix[r][c] == matrix[r][f] && matrix[r][c] > 0 && matrix[r][f] > 0 {
						fmt.Printf("Error")
						return
					}
				}
			}
		}

		//randomly select a number from 1–9 and place it in the empty cell of the matrix.
		pickNum(matrix)

		//print the completed sudoku matrix
		for r := 0; r < len(matrix); r++ {
			for c := 0; c < len(matrix[r]); c++ {
				fmt.Printf("%v ", matrix[r][c])
			}
			fmt.Println()
		}

	} else {
		fmt.Println("Error")
	}
}

// 1. Randomly select a number from 1–9 and place it in the empty cell of the matrix.
// 2. Check the newly placed number against its row, column, and 3×3 box for conflicts.
// 3. If a conflict is found, reset the cell to zero, call the function again, and repeat from step 1.
func pickNum(matrix [][]int) bool {
	for i := 0; i < len(matrix); i++ {
		for j := 0; j < len(matrix[i]); j++ {
			num := matrix[i][j]
			if num == 0 {
				for n := 1; n <= 9; n++ {
					if IsValidNumToAdd(matrix, n, i, j) {
						matrix[i][j] = n
						if pickNum(matrix) {
							return true
						}
						matrix[i][j] = 0
					}
				}
				return false
			}
		}
	}
	fmt.Println(matrix)
	return true
}

// 1.check the number in the same column at current pointed empty box's position
// 2.check the number in the same row at current pointed empty box's position
// 3.check the number in the 3*3 box at current pointed empty box's position
func IsValidNumToAdd(matrix [][]int, num, row, col int) bool {

	//column check
	for c := 0; c < len(matrix); c++ {
		if matrix[row][c] == num {
			return false
		}
	}

	//row check
	for r := 0; r < len(matrix); r++ {
		if (matrix[r][col]) == num {
			return false
		}
	}

	//3 *3 box check
	rb := (row / 3) * 3
	cb := (col / 3) * 3

	for i := 0; i < 3; i++ {
		for j := 0; j < 3; j++ {
			if matrix[rb+i][cb+j] == num {
				return false
			}
		}
	}
	return true
}

func StringToInt(s string) int {
	if s == "" || s == "." {
		return 0
	}
	n := 0
	for _, r := range s {
		digit := int(r - '0')
		n = n*10 + digit
	}
	return n
}

func IntToString(n int) string {
	if n == 0 {
		return "0"
	}
	result := ""
	for n > 0 {
		digit := n % 10
		char := rune('0' + digit)
		result = string(char) + result
		n /= 10
	}
	return result
}
